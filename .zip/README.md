# AngularcertificationProject

# Author: Midhun

# backend
json-server --watch db.json