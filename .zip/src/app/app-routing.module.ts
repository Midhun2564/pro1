import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfirmOrderComponent } from './components/confirm-order/confirm-order.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { PasswordResetComponent } from './components/password-reset/password-reset.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { AddressComponent } from './components/settings/address/address.component';
import { PaymentComponent } from './components/settings/payment/payment.component';
import { ProfileComponent } from './components/settings/profile/profile.component';

const routes: Routes = [
  {path:'',pathMatch:'full',redirectTo:'/register'},
  {path:'register',component:RegistrationComponent},
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'passwordreset',component:PasswordResetComponent},
  {path:'settings/profile',component:ProfileComponent},
  {path:'settings/address',component:AddressComponent},
  {path:'settings/payment',component:PaymentComponent},
  {path:'confirm-order',component:ConfirmOrderComponent}
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
