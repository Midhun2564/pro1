import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';
import { PasswordResetComponent } from './components/password-reset/password-reset.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { SettingsComponent } from './components/settings/settings.component';
import { ProfileComponent } from './components/settings/profile/profile.component';
import { AddressComponent } from './components/settings/address/address.component';
import { PaymentComponent } from './components/settings/payment/payment.component';
import { ConfirmOrderComponent } from './components/confirm-order/confirm-order.component';
import { OrderTrackingComponent } from './components/order-tracking/order-tracking.component';
import { HttpClientModule} from '@angular/common/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConfirmPasswordDirective } from './shared/confirm-password.directive';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ModelComponent } from './components/model/model.component';

@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    PasswordResetComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    SettingsComponent,
    ProfileComponent,
    AddressComponent,
    PaymentComponent,
    ConfirmOrderComponent,
    OrderTrackingComponent,
    ConfirmPasswordDirective,
    ModelComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
