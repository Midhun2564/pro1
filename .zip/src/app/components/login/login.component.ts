import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;


  constructor(private userService:UserService,private router:Router) { 
    this.loginForm={} as FormGroup;
  }

  ngOnInit(): void {
    this.loginForm= new FormGroup({
      email:new FormControl('',[Validators.required,Validators.email]),
      password:new FormControl('',[Validators.required]),
    })
  }
  onSubmit(){
    this.userService.login().subscribe(
      (res:any)=>{
        const user= res.find((a:any)=>{
          return a.email===this.loginForm.value.email && a.password===this.loginForm.value.password
        });
        if(user){
          window.alert("user login is successfull");
          this.router.navigate(['/home']);
          localStorage.setItem('currentUser',JSON.stringify(user))

        }else{
          window.alert('Wrong data is entered')
        }
      }
    )
  }

}
