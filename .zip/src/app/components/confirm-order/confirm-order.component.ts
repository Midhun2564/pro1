import { Component, OnInit } from '@angular/core';
import { Cart } from 'src/app/models/cart.model';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-confirm-order',
  templateUrl: './confirm-order.component.html',
  styleUrls: ['./confirm-order.component.css']
})
export class ConfirmOrderComponent implements OnInit {

  cart:Cart[]=[];
  public subTotal:number =0
  public shippingCharge:number=50;
  public total:number=0;
  constructor(private cartService:CartService ) { }

  ngOnInit(): void {
    this.cart= this.cartService.cartItemList
    console.log(this.cartService.cartItemList)
    this.subTotal= this.cartService.getTotalPrice();
    this.total=this.subTotal+this.shippingCharge;


  }
  remove(product:any){
    this.cartService.removeCartItem(product)

}
}
