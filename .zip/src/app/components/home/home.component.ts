import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { Cart, Order } from 'src/app/models/cart.model';
import { Food } from 'src/app/models/food.model';
import { User } from 'src/app/models/user.model';
import { CartService } from 'src/app/services/cart.service';
import { FoodService } from 'src/app/services/food.service';
import { OrderService } from 'src/app/services/order.service';
import { SettingsService } from 'src/app/services/settings.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public data:Food[]=[];
  public dishName:string='';
  public restaurant:string='';
  public description:string='';
  public cost:number=0;
  public rating:number=0;
  public imageUrl:string='';
  searchForm:FormGroup;
  isCart:boolean; 
  currentUser: User;
  address1:boolean=false;
  payment:boolean=false;
  public cartL:Cart[]=[]
  public ICart: Cart={
    id: 0,
    restaurant: '',
    dishName: '',
    description: '',
    rating: 0,
    cost: 0,
    imageUrl: '',
    qty: 0,
    total: 0
  };
  

  constructor(
    private router:Router,
    private settingService:SettingsService,
    private foodService:FoodService, 
    private cartService:CartService,
    private orderService:OrderService) 
    { 
    this.searchForm= {} as FormGroup;
    this.isCart=false;
    this.currentUser=this.settingService.currentUserValue
    
    
   
    
  }

  ngOnInit(): void {
    this.initializeForm();
    this.getFood();
    
    
    
    this.address1=(Object.keys(this.currentUser.address[0]).length===0||
                   this.currentUser.address===undefined|| Object.keys(this.currentUser.payment[0]).length===0
                   || this.currentUser.payment===undefined);
                   console.log(this.address1);
    
  
    

  }


  public initializeForm(){
    this.searchForm= new FormGroup({
      name:new FormControl('')
    }) 
  }

  public getFood(){
    this.foodService.getFood().subscribe(
      (res:any)=>{
        this.data=res;
        this.cartL=res;
        this.data.forEach((a:any)=>{
          Object.assign(a,{qty:1,total:a.cost})
        }),
        this.cartL.forEach((a:any)=>{
          Object.assign(a,{qty:1,total:a.cost})
        })
      }
    )

  }

  search(){
    this.foodService.getFood().subscribe(
      (res:any)=>{
       
        
        const food1=res.filter((a:any)=>{
          const arr=a.dishName.toLowerCase().split(" ");
          
      
          
           return (this.searchForm.value.name === arr[0] || 
                  this.searchForm.value.name=== arr[1] ||
                this.searchForm.value.name=== arr[2] )

          
          
        });
        if (food1){
          this.data=food1
        }
        
      }
    )

    

  }
  addToCart(){
    

   if (this.cartService.cartItemList.indexOf(this.ICart)<0){
    this.cartService.addtoCart(this.ICart);
    
   }else{
    this.ICart.qty +=1;
    this.ICart.total +=this.ICart.cost
    
   }

   window.alert("For visiting the Cart page . pls click the cart icon in the header, click the confirm add to cart button to increase the quantity")
  

  }
  place(){
    const order={
      id: this.ICart.id,
      userid: 23455,
      feedId: Math.floor((Math.random() * 20) + 1),
      orderstatus: "placed",
      paymentStatus: "paid",
      orderDateTime: " 10/10/2021:7:30pm "

    }
    
    
    this.orderService.placeOrder(order).subscribe(
      (res)=>{
        console.log(res);
        
      }
    )
  }
  place1(item:any){
    this.isCart=true;
    this.ICart= item;

  }
  cart(item:any){
    this.isCart=false;
    this.ICart= item;
 
  
   
  }
 
   
 


  



  

}
