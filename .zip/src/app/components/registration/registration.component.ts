import { Component, OnInit } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  userForm:FormGroup;
  isSubmitted:boolean;

  constructor(private userService:UserService, private router:Router) {
    this.userForm= {} as FormGroup;
    this.isSubmitted=false;
   }

  ngOnInit(): void {
    this.userForm= new FormGroup({
      firstName:new FormControl('',[Validators.required]),
      lastName:new FormControl('',[Validators.required]),
      email:new FormControl('',[Validators.required,Validators.email]),
      password:new FormControl('',[Validators.required,Validators.minLength(6)]),
      cPassword:new FormControl('',[Validators.required]),
    })
  }
  onSubmit(){
    this.userService.login().subscribe(
      (res:any)=>{
        const user= res.find((a:any)=>{
          return a.email==this.userForm.value.email
        });
        if(user){
          window.alert('user already exists, pls login to continue.. ');
          this.router.navigate(['/login'])
        }else{
          this.userService.register(this.userForm.value).subscribe(
            (data:any)=>{
              window.alert("User registered successfully");
              this.router.navigate(['/login'])
      
            }
          )

        }
      }
    )

  }

}
