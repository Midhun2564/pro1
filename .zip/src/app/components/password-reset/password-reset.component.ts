import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.css']
})
export class PasswordResetComponent implements OnInit {
  public isSubmit:boolean;
  public userName:string;
  passwordForm:FormGroup;
  public user:User[]=[];

  constructor(private userService:UserService,private router:Router) {
    this.isSubmit=false;
    this.userName="";
    this.passwordForm={} as FormGroup;
   }

  ngOnInit(): void {
    this.passwordForm=  new FormGroup({
      firstName:new FormControl('',[Validators.required]),
      lastName:new FormControl('',[Validators.required]),
      email:new FormControl('',[Validators.required,Validators.email]),
      password:new FormControl('',[Validators.required]),
      cPassword:new FormControl('',[Validators.required]),

      

    })
  }

  forgotPassword(){
    this.userService.login().subscribe(
      (res:any)=>{
        const user= res.find((a:any)=>{
           return a.email=== this.passwordForm.value.email;
        })
        if(user){
          this.isSubmit=true;
          console.log(user)
        

        }else{
          window.alert('User not exist, create ana account')
          this.router.navigate(['/register'])
        }
      }
    )
  }
  resetPassword(){
    this.userService.login().subscribe(
      (res:any)=>{
        const user=res.find((a:any)=>{
          return a.email=== this.passwordForm.value.email;
       });
       if(user){
        console.log(user);
        const id1=user.id;
        this.passwordForm.value.firstName= user.firstName;
        this.passwordForm.value.lastName= user.lastName;

        
        console.log('id is',id1)
        this.userService.resetPassword(id1,this.passwordForm.value).subscribe(
          (res)=>{
            console.log(res)
            window.alert('password changed successfully, pls log in to continue');
            this.router.navigate(['/login'])
          }
        );
       
        
       }
      }
    )
   

  }

}
