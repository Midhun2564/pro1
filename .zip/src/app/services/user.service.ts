import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) {
    
   }

  public url1=" http://localhost:3000/users"


  register(user:User):Observable<User>{
    return this.http.post<User>(this.url1,user);
  }

  login():Observable<User>{
    return this.http.get<User>('http://localhost:3000/users')
  }
  getUserById(id:any):Observable<User>{
    return this.http.get<User>('http://localhost:3000/users/'+id)
  }
  resetPassword(id:any,user:User){
    return this.http.put('http://localhost:3000/users/'+id,user)
  }

  
}
