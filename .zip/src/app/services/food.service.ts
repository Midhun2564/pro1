import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, observable } from 'rxjs';
import { Cart } from '../models/cart.model';
import { Food } from '../models/food.model';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
  cart:Food[]=[]

  constructor(private http:HttpClient) { }
  public url=" http://localhost:3000/foodList"

  getFood():Observable<Food>{
    return this.http.get<Food>(this.url)

  }
  addToCart(food:any){
    return this.cart.push(food)
  }
  

}
