import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../models/cart.model';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { }

  public url= " http://localhost:3000/orders"
  

  placeOrder(order:Order):Observable<Order>{
    return this.http.post<Order>(this.url,order)
  }

}
