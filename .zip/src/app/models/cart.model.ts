

export interface Cart{
    id: number;
    restaurant: string,
    dishName: string,
    description: string,
    rating: number,
    cost: number,
    imageUrl: string;
    qty:number;
    total:number
  }

  export interface Order{
    id: number,
    userid: number,
    feedId: number,
    orderstatus: string,
    paymentStatus: string,
    orderDateTime: string;
  }
 
 
