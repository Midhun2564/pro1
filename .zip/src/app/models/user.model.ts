export interface User {
    id:number;
    fname:string;
    lName:string;
    email:string;
    password:string;
    cPassword:string;
    phoneNumber?:number;
    address:any;
    payment:any;
    


}
