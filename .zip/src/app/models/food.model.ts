export interface Food{
    id: number;
    restaurant: string,
    dishName: string,
    description: string,
    rating: number,
    cost: number,
    imageUrl: string;
    qty?:number;
    total?:number
  }
