import { ConfirmPasswordDirective } from './confirm-password.directive';

describe('ConfirmPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new ConfirmPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
