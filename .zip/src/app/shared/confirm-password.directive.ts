import { Directive, Input } from '@angular/core';
import { FormGroup, NG_VALIDATORS } from '@angular/forms';
import { ConfirmPasswordValidate } from './confirm-password.validator';

@Directive({
  selector: '[confirmPassword]',
  providers: [{ provide: NG_VALIDATORS, useExisting: ConfirmPasswordDirective, multi: true }]

})
export class ConfirmPasswordDirective {

  @Input('confirmPassword')confirmPassword: string[] 
  constructor() { 
    this.confirmPassword=[]
  }

  public validate(formGroup: FormGroup): null {
    return ConfirmPasswordValidate(this.confirmPassword[0], this.confirmPassword[1])(formGroup);
    }


}
